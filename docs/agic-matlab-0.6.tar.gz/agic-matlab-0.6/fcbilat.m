function [Mp, Mw] = fcbilat(Vg, Mg, Mt, sds, sdr)
%Fast Cross Bilateral Filtering using Grid
%By Shawn Chang (Zhang Xiang) @ Tianjin University
%Version 0.1, 12/11/2010
%
%Usage: [Mp, Mw] = fbilat(Vg, Mg, Mt, sds, sdr)
%       Mp:     Output filtered matrix [Already been devided by Mw]
%       Mw:     Output filtered weights
%       Vg:     Input ranges
%       Mg:     Input edge matrix
%       Mt:     Input target matrix for filtering
%       sds:    Spacial Standard Deviation, default to 1/16 of Mg's size.
%       sdr:    Range Strandard Deviation, default to 1/10 of Vg's range.
%
%Note:  This function used no downsampling

%Default sds and sdr
if ~exist('sds','var')
    sds = sqrt(sum(size(Mg).^2))/16;
end
if ~exist('sdr','var')
    sdr = (Vg(numel(Vg)) - Vg(1))/10;
end

%Preallocate data
Dq = zeros([size(Mg), numel(Vg)]);
Do = zeros([size(Mg), numel(Vg)]);

%Grid bulding up
for i=1:numel(Vg)
    Do(:,:,i) = double(Mg == Vg(i));
    Dq(:,:,i) = Do(:,:,i).*Mt;
end

%Gaussian Kernel
Dk = zeros(round(2*round(sds)+1), round(2*round(sds)+1), round(2*round(numel(Vg)*sdr/(Vg(numel(Vg)) - Vg(1)))+1));
Mk = fspecial('gaussian', [size(Dk,1), size(Dk,2)], sds);
Vk = fspecial('gaussian',[size(Dk,3),1], sdr);
for i = 1:size(Dk,3)
    Dk(:,:,i) = Mk.*Vk(i);
end

%Convolution
%Dp = convn(Dq,Dk,'same');
%Dw = convn(Do,Dk,'same');

%FFT convolution to the same size
Dp=ifftn(fftn(Dq,size(Dq)+size(Dk)-1).*fftn(Dk,size(Dq)+size(Dk)-1));
Dw=ifftn(fftn(Do,size(Do)+size(Dk)-1).*fftn(Dk,size(Do)+size(Dk)-1));
p=(size(Dk)-1+mod((size(Dk)-1),2))/2;
Dp=Dp(p(1)+1:p(1)+size(Dq,1),p(2)+1:p(2)+size(Dq,2),p(3)+1:p(3)+size(Dq,3));
Dw=Dw(p(1)+1:p(1)+size(Do,1),p(2)+1:p(2)+size(Do,2),p(3)+1:p(3)+size(Do,3));

%Find Mp and Mw
Mp = zeros(size(Mg));
Mw = zeros(size(Mg));
for i=1:numel(Vg)
    Mdp = Dp(:,:,i);
    Mdw = Dw(:,:,i);
    Mp(Mg==Vg(i)) = Mdp(Mg == Vg(i));
    Mw(Mg==Vg(i)) = Mdw(Mg == Vg(i));
end

%Divide
Mp = Mp./Mw;