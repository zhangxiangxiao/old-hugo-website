%Main Driver and Input/Output for AGIC
%By Shawn Chang (Zhang Xiang) @ TJU
%12/08/2010, Version 0.6
%
%The script needs two images.
%This program is accelerated using downsampled image with fixed width 512
%   to compute spcial mapping and color correspondence.
warning('off','all');

%Define constants
tau = 15;
hist_elim = true;
flagLP = true;
colorscale = [16; 16];

%Prepare used values
time = 0;
Vg = (0:255)';


%Initialize Images
input('Please input the filename of the source image: ','s');
input('Please input the filename of the target image: ','s');
disp('Info: Filenames acquired, processing...');
t = clock;
IS = iminit(InameS);
IT = iminit(InameT);
time = time + etime(clock,t);
disp('Info: Spacial Mapping Computed.');

%Spacial Segments Generation
t = clock;
md_sseg;
time = time + etime(clock,t);
disp('Info: Spacial Segments Generated.');
disp(['      Number of Spacial Segments: ' num2str(IS.Ssseg.n)]);

%Luminance Z-Points Generation
t = clock;
md_lz;
time = time + etime(clock,t);
disp('Info: Luminance Z-Points Generated.');
for i = 1:IS.Ssseg.n
    disp(['      Number of Z-Points in Spacial Segments #' num2str(i) ': ' num2str(IS.SZl.Vn(i))]);
end

%Average Color Computaion and Luminance-Color Correspondence
t = clock;
IR = IT;
md_lc;
time = time + etime(clock,t);
disp('Info: Luminance-Color Correspondence Computed.');

%Colorization
t = clock;
md_color;
time = time + etime(clock,t);
disp('Info: Colorization Results Computed.');

%Final Output
disp('Info: Processing done.');
disp(['      Elapsed time is: ' num2str(time)]);

%Plot and Draw
md_plot;
disp('Info: Results Plotted.');
md_wrtfl;
disp('Info: Record Written to File.');
