function Vw = lwrw(Vg, x, tau)
%Locally Weighted Regresssion Weights Calculation
%
%by Shawn Chang @ TJU, Version 0.1, 02/09/2010
%
%Usage: Vw = lwrw(Vg, x, tau)
%       Vg: Input vector of x
%       x:  The central x to calculate
%       tau:The bandwidth parameter
%       Vw: Output vector of weights corresponding to each x in Vg
%
%Note: The algorithm uses the following formula to compute weights:
%      w = exp(-||x^(j)-x||^2/(2tau^2))

Vw = exp(-((Vg - x).^2)/2/tau^2);
