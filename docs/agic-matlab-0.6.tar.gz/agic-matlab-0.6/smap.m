function M = smap(Mg)
%Spacial mapping function
%By Shawn Chang (Zhang Xiang) @ Tianjin University
%Version 0.1, 10/31/2010
%
%Usage: M = smap(Mg)
%       M:  Output spacial mapping matrix
%       Mg: Input grayscale matrix
%
%Note:  This function is a dummy function.

M = smapbilat(Mg);