function Davgcol = avgcol(Vg, Dycc, Msseg, n)
%Average Color Computation
%By Shawn Chang (Zhang Xiang) @ Tianjin University
%Version 0.1, 11/07/2010
%
%Usage: Davgcol = avgcol(Vg, Ddycc, Msseg, n)
%       Davgcol:    Output average color
%       Vg:         Grayscales
%       Dycc:      Input Color Array in YCbCr
%       Msseg:      Spacial Segments
%       n:          Number of spacial segments


%Preparation
Davgcol = zeros(numel(Vg),n,3);
Davgcol(:,:,2) = 128;
Davgcol(:,:,3) = 128;
My = squeeze(Dycc(:,:,1));
Mcb = squeeze(Dycc(:,:,2));
Mcr = squeeze(Dycc(:,:,3));

for i = 1:n
    Msmap = (Msseg == i);
    for j = 1:numel(Vg)
        Mmap = (Msmap & My == Vg(j)); 
        Num = sum(sum(double(Mmap))) + 1;
        Davgcol(j,i,:) = [Vg(j); (sum(Mcb(Mmap))+128)/Num; (sum(Mcr(Mmap))+128)/Num];
    end
end

Davgcol = uint8(Davgcol);