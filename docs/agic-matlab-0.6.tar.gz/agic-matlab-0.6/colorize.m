function Dycc = colorize(Vg, Mg, Ms, Davgcol, flagLP, s)
%Colorization function
%By Shawn Chang (Zhang Xiang) @ Tianjin University
%Version 0.1, 11/08/2010
%
%Usage: Dycc = colorize(Vg, Mg, Ms, Davgcol)
%       Dycc:       Output YCbCr color image in uint8
%       Vg:         Input Scale vector
%       Mg:         Input grayscale matrix
%       Ms:         Input spacial mapping matrix
%       Davgcol:    Input colorization mapping
%       flagLP:     Input flag indicating Luminance Preserving
%       s:          Scaling factor

if ~exist('flagLP','var')
    flagLP = true;
end

if ~exist('s', 'var')
    s = 1;
elseif s < 1
    s = 1;
end

%Preparation
Davgcol = double(Davgcol);
My = double(Mg);
Mcb = 128*ones(size(Mg));
Mcr = 128*ones(size(Mg));
maxG = Vg(numel(Vg));
%wh = waitbar(0,'Colorizing...');

%Scaling
Mg = double(Mg)/s(1);
Mg = fix(Mg);
Vg = [0:fix(maxG/s(1))];
Ms = double(Ms)/s(2);
Ms = fix(Ms);
Vs = [0:fix(maxG/s(2))];
Davgcol = imresize(Davgcol, [numel(Vg), numel(Vs)]);

%Colorizing
if flagLP == true
    for i = 1:numel(Vg)
        %waitbar(i/numel(Vg),wh);
        Mm = Mg == Vg(i);
        for j = 1:numel(Vs)
            Mmap = Mm & (Ms == Vs(j));
            %My(Mmap) = Davgcol(i,j,1);
            Mcb(Mmap) = Davgcol(i,j,2);
            Mcr(Mmap) = Davgcol(i,j,3);
        end
    end
else
    for i = 1:numel(Vg)
        %waitbar(i/numel(Vg),wh);
        Mm = Mg == Vg(i);
        for j = 1:numel(Vs)
            Mmap = Mm & (Ms == Vs(j));
            My(Mmap) = Davgcol(i,j,1);
            Mcb(Mmap) = Davgcol(i,j,2);
            Mcr(Mmap) = Davgcol(i,j,3);
        end
    end
end

Dycc = uint8(cat(3,My,Mcb,Mcr));

%Close and clear
%close(wh);