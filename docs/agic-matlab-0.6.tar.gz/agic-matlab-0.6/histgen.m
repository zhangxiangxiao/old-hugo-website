function Vh = histgen(Vg, Mg, Mm)
%Histogram generation with mapping
%By Shawn Chang (Zhang Xiang) @ Tianjin University
%Version 0.3, 11/21/2010
%
%Usage: Vh = histgen(Vg, Mg, Mm)
%       Vh: Output vector of histogram values
%       Vg: Input vector of luminance ranges
%       Mg: Input matrix of image values
%       Mm: Mapping values (logic values, optional)
%
%Note:  The histogram generated is normalized to [0,1]

if ~exist('Mm','var');
    Mm = boolean(ones(size(Mg)));
end

%Preparation
Vh = zeros(size(Vg));
Mm = boolean(Mm);
Mg = fix(Mg);
Mg(Mg < 0) = 0;
Mg(Mg > max(Vg)) = max(Vg);

n = numel(Mg(Mm));
for i = 1:numel(Vg)
    Vh(i) = sum(sum(Mg(Mm) == Vg(i))) / n;
end