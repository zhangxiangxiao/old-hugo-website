function M = smapbilat(Mg)
%Spacial mapping function - Textureness Mapping
%By Shawn Chang (Zhang Xiang) @ Tianjin University
%Version 0.2, 04/06/2011
%
%Usage: M = smapcontr(Mg)
%       M:  Output Mapping, in 8-bit
%       Mg: Input grayscale image
%
%Note:  This function uses the following functions:
%       texsumm
%       texresh
%       texpre
%       texcontr

%Define constants
c = 50;
LUM_DOWNSAMPLE = 16;
Vg = (0:fix(255/LUM_DOWNSAMPLE))';

%Preparation
t = size(Mg)/2;
s = sqrt(sum((2*t).^2));

%Bilateral Decomposition
B = LUM_DOWNSAMPLE*fbilat(Vg, fix(double(Mg)/LUM_DOWNSAMPLE));
D = abs(log(double(Mg) + 1) - log(B + 1));
B = log(B+1);

%High-Pass filter
[X Y] = meshgrid(1:size(B,2), 1:size(B,1));
Mfh = exp(-((X-t(2)).^2 + (Y-t(1)).^2)/(2*(s/8)^2));
T = abs(real(ifft2((fft2(B)+fft2(D)).*Mfh)));

%Gaussian Blur
Y = fcbilat(Vg, fix(double(Mg)/LUM_DOWNSAMPLE), T, sqrt(sum(size(Mg).^2))/8);
Y = Y-min(Y(:));

%iSAGC Procedure
Y = Y/max(Y(:));
Y = wsagc(1-Y, 0.7);
Y = 1 - Y;
M = uint8(Y*256);