%Plotting for AGIC
%By Shawn Chang (Zhang Xiang) @ TJU
%Version 0.2, 11/11/2010
%
%IR must have been initialized
%Spacial Segments must have been generated
%Luminance Z-points must have been computed
%Luminance-Color Correspondence must have been computed.
%Colorization must have been done
%Plottings must exist

%Writing Records
dlmwrite('Report',['Report for AGIC with spacial mapping in constrast from ' InameS ' to ' InameT],'delimiter','');
dlmwrite('Report', ['Date and Time: ' datestr(now)], '-append', 'delimiter','');
dlmwrite('Report',['Number of Spacial Segments: ' num2str(IS.Ssseg.n)], '-append', 'delimiter', '');
for i = 1:IS.Ssseg.n
    dlmwrite('Report',['      Number of Z-Points in Spacial Segments #' num2str(i) ': ' num2str(IS.SZl.Vn(i))],'-append','delimiter','');
end
dlmwrite('Report', ['Elapsed time is: ' num2str(time)], '-append', 'delimiter', '');

%Write Images
imwrite(repmat(IT.Dycc(:,:,1),[1,1,3]), [InameT '_G'], 'png');
imwrite(repmat(IS.Msmap, [1,1,3]),[InameS '_Smap'],'png');
imwrite(repmat(IT.Msmap, [1,1,3]),[InameT '_Smap'],'png');
imwrite(repmat(Data.Seg.S, [1,1,3]), [InameS '_Sseg'], 'png');
imwrite(repmat(Data.Seg.T, [1,1,3]), [InameT '_Sseg'], 'png');
imwrite(IR.Drgb,['Result'],'png');

%Write plots
print (Fhs, '-depsc', ['SandT_HS']);
print (FhlS, '-depsc', [InameS, '_HL']);
print (FhlT, '-depsc', [InameT, '_HL']);
print (FC, '-depsc', ['SandT', '_CC']);
