function Y = rgb2ycc(X)
%RGB to JFIF YCbCr Color Space Conversion
%By Shawn Chang (Zhang Xiang) @ Tianjin University
%Version 0.1. 09/23/2010
%
%Usage: Y = rgb2ycc(X)
%       Y: Output YCbCr values, uint8
%       X: Input RGB values, uint8

X = double(X);
Y = zeros(size(X));
Y(:,:,1) = 0.299*X(:,:,1) + 0.587*X(:,:,2) + 0.114*X(:,:,3);
Y(:,:,2) = -0.1687*X(:,:,1) - 0.3313*X(:,:,2) + 0.5*X(:,:,3) + 128;
Y(:,:,3) = 0.5*X(:,:,1) - 0.4187*X(:,:,2) - 0.0813*X(:,:,3) + 128;
Y = uint8(Y);