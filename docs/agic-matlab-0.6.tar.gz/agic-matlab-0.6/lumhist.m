function Mhl = lumhist(Vg, Mg, Msseg, n)
%Luminance histogram generation
%By Shawn Chang (Zhang Xiang) @ Tianjin University
%Version 0.1, 11/06/2010
%
%Usage: Mhl = lumhist(Vg, Mg, Msseg, n)
%       Mhl:    Output matrix of histograms. One column for each segments.
%       Mg:     Grayscale map
%       Msseg:  Spacial Segments
%       n:      Number of spacial segments
%
%Note:  This function uses histgen with mapping.

Mhl = zeros(numel(Vg), n);
for i = 1:n
    Mhl(:,i) = histgen(Vg, Mg, Msseg == i);
end