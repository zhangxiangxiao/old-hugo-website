function param = lwrlin(Vg, Vh, tau)
%Batch Locally Weighted Regresssion linear Fitting
%
%by Shawn Chang @ TJU, Version 0.2, 10/30/2010
%
%Usage: param = lwrlin(Vg, Vh, tau)
%       Vg: Input vector of x
%       Vh: Input vector of y
%       tau:The bandwidth parameter
%       param: Output matrix of fitted linear model
%
%Note: The algorithm uses the lwrw function to compute weights

param=zeros(size(Vg,1), 2);
X=zeros(size(Vg,1),2);
for i = 1:size(Vg,1)
    weights = lwrw(Vg,Vg(i),tau);
    X(:,1)=sqrt(weights);
    X(:,2)=sqrt(weights).*Vg;
    y = sqrt(weights).*Vh;
    param(i,:) = (X\y)';
end
