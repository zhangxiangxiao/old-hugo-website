function DavgcolR = gcolcor(Vg, DavgcolT, VzasS, VzasT)
%Global Luminance-Color Corresponence Computation
%By Shawn Chang @ Tianjin University
%Version 0.1, 11/08/2010
%
%Usage: DavgcolR = gcolcor(Vg, DavgcolT, VzasT, n)
%       DavgcolR:       Colorization data
%       Vg:             Spacial mapping vector
%       Davgcol:        Target average color
%       VzasS, VzasT:   Adjusted spacial Z-points
%
%Note:  This function uses function wcw

%Preparation
Davgcol = zeros(numel(Vg), numel(Vg), size(DavgcolT,3));
DavgcolR = zeros(numel(Vg), numel(Vg), size(DavgcolT,3));
Vzas = [Vg(1);VzasT;Vg(numel(Vg))];

k = 2;
for i = 1:numel(Vg)
    if Vg(i) <= Vzas(k)
        Davgcol(:,i,:) = double(DavgcolT(:,k-1,:));
    else
        k = k+1;
        Davgcol(:,i,:) = double(DavgcolT(:,k-1,:));
    end
end

%Weighted Computation on Spacial Values
MW = wcw(Vg, VzasS, VzasT);
for i = 1:numel(Vg)
    for j = 1:size(DavgcolT,3)
        DavgcolR(i,:,j) = (MW*(squeeze(Davgcol(i,:,j)))'./sum(MW,2))';
    end
end

DavgcolR = uint8(DavgcolR);