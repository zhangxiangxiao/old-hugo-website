function [ZS, TS, ZT, TT]=zadjust(inZS, inTS, inZT, inTT, VhS, VhT)
%0-Points Adjustment
%
%by Shawn Chang @ TJU, Version 0.2, 02/20/2010
%
%Usage: [ZS, TS, ZT, TT]=zadjust(VhS, VhT, inZS, inTS, inZT, inTT)
%       inZS, inTS, inZT, inTT: Input sequence sets
%       ZS, TS, ZT, TT:         Output sequence sets
%       VhS, VhT:               Input histogram values
%
%Note:  The following functions are used by this function:
%       fradjust:   Font-Rear 0-Points Adjustment
%       padjust:    Pair 0-Points Adjustment

[ZS, TS, ZT, TT] = fradjust(inZS, inTS, inZT, inTT);
delta = abs(size(TS,1) - size(TT,1));
if size(TS,1) > size(TT,1)
    [ZS, TS] = padjust(VhS, ZS, TS, delta);
elseif size(TS,1) < size(TT,1)
    [ZT, TT] = padjust(VhT, ZT, TT, delta);    
end