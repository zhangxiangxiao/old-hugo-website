function DavgcolT = lcolcor(Vg, DavgcolS, MzalS, MzalT, n, Vn)
%Local Luminance-Color Correspondence Calculation
%By Shawn Chang (Zhang Xiang) @ Tianjin University
%Version 0.1, 11/08/2010
%
%Usage: DavgcolT = lcolcor(Vg, DavgcolS, MzalS, MzalS, n, Vn)
%       DavgcolT:   Target average color
%       Vg:         Luminance vector
%       DavgcolT:   Source average color
%       MzalS:      Source adjusted luminance Z-points
%       MzalT:      Target adjusted luminance Z-points
%       n:          number of spacial segments
%       Vn:         number of luminance-zpoints
%
%Note:  This function uses the function wcw to compute weights

DavgcolT = zeros(size(DavgcolS));

for i = 1:n
    MW = wcw(Vg, MzalS(1:Vn(i),i), MzalT(1:Vn(i),i));
    for j = 1:size(DavgcolS,3)
        DavgcolT(:,i,j) = MW*double(DavgcolS(:,i,j))./sum(MW,2);
    end
end

DavgcolT = uint8(DavgcolT);