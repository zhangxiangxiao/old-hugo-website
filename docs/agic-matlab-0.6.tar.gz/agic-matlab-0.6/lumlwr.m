function Dthc = lumlwr(Vg, Mhl, n, tau)
%Locally Weighted Regression on Luminance
%By Shawn Chang (Zhang Xiang) @ Tianjin University
%Version 0.1, 11/06/2010
%
%Usage: Dthc = lumlwr(Vg, Mhl, n)
%       Dthc:   Output regression results. 3-D array.
%       Vg:     Input scale vector
%       Mhl:    Input luminance values
%       n:      Number of segments
%       tau:    Regression width
%
%Note: This function uses lwrlin for calculation of regression restuls.

%Preparation
Dthc = zeros(numel(Vg), 2, n);

%Computation
for i = 1:n
    Dthc(:,:,i) = lwrlin(Vg, Mhl(:,i), tau);
end