function MW = wcw(Vg, ZS, ZT)
%Weights matrix generation
%
%by Shawn Chang @ TJU, Version 0.3, 10/30/2010
%
%Usage: MW=wcw(ZS, ZT)
%       MW: Output matrix of weights, each line for each value in Vg
%       ZS: Input parameter of the histogram z-points set for source image
%       ZT: Input parameter of the histogram z-points set for target image
%
%Note:  This function uses lwrw to compute weights

n = numel(Vg);
MW=zeros(n,n);

ZS = [Vg(1);ZS;Vg(n)];
ZT = [Vg(1);ZT;Vg(n)];
deltaS = ZS(2:numel(ZS)) - ZS(1:(numel(ZS)-1));
deltaT = ZT(2:numel(ZT)) - ZT(1:(numel(ZT)-1));
tau=deltaS./deltaT;

k=1;
for j = 1:n
    if Vg(j) <= ZT(k+1);
        mu = (Vg(j)-ZT(k))/deltaT(k)*deltaS(k)+ZS(k);
        MW(j,:) = lwrw(Vg,mu,tau(k))';
    else
        k = k + 1;
        mu = (Vg(j)-ZT(k))/deltaT(k)*deltaS(k)+ZS(k);
        MW(j,:) = lwrw(Vg,mu,tau(k))';
    end
end