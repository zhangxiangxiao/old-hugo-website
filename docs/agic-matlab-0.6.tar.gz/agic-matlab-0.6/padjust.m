function [Z, T]=padjust(Vh, inZ, inT, delta)
%Pair 0-Points Adjustment
%
%by Shawn Chang @ TJU, Version 0.3, 09/23/2010
%
%Usage: [Z, T]=padjust(Vh, inZ, inT, delta)
%       Vh:         Input Histogram values
%       inZ, inT:   Input sequence sets
%       delta:      Input difference of sequence sets
%       Z,T:        Output sequence sets

sizeT = size(inT,1);

% append
inZ=[0;inZ;255];
inT=[-inT(1);inT;-inT(sizeT)];

while delta > 0
    index = 0;
    minval = inf;
    for i = 2:(size(inZ,1) - 2)
        if Vh(inZ(i)+1) > Vh(inZ(i+1)+1) && Vh(inZ(i)+1) < Vh(inZ(i+2)+1) && Vh(inZ(i-1)+1) < Vh(inZ(i+1)+1) && abs(Vh(inZ(i)+1) - Vh(inZ(i+1)+1)) < minval
            index = i;
            minval = abs(Vh(inZ(i)+1) - Vh(inZ(i+1)+1));
        elseif Vh(inZ(i)+1) < Vh(inZ(i+1)+1) && Vh(inZ(i)+1) > Vh(inZ(i+2)+1) && Vh(inZ(i-1)+1) > Vh(inZ(i+1)+1) && abs(Vh(inZ(i)+1) - Vh(inZ(i+1)+1)) < minval
            index = i;
            minval = abs(Vh(inZ(i)+1) - Vh(inZ(i+1)+1));
        end
    end
    
    if index == 0
        for i = 2:(size(inZ,1) - 2)
            if abs(Vh(inZ(i)+1) - Vh(inZ(i+1)+1)) < minval
                index = i;
                minval = abs(Vh(inZ(i)+1) - Vh(inZ(i+1)+1));
            end
        end
    end
    
    inZ = inZ([1:(index-1),(index+2):(size(inZ,1))]);
    inT = inT([1:(index-1),(index+2):(size(inT,1))]);
    delta = delta - 2;
end

Z=inZ(2:(size(inZ,1) - 1));
T=inT(2:(size(inT,1) - 1));
