%Luminance-Color Correspondence Model for AGIC
%By Shawn Chang (Zhang Xiang) @ TJU
%Version 0.1, 11/07/2010
%
%IT, IS and IR must have been initialized
%Spacial Segments must have been generated
%Luminance Z-points must have been computed

%Compute Source Average Color
IS.Davgcol = avgcol(Vg, IS.Ddycc, IS.Ssseg.Msseg, IS.Ssseg.n);

%Compute Local Weighted Color Correspondence for Target
IT.Davgcol = lcolcor(Vg, IS.Davgcol, IS.SZl.Mzal, IT.SZl.Mzal, IS.Ssseg.n, IS.SZl.Vn);

%Compute Global Weighted Color Correspondence
IR.Davgcol = gcolcor(Vg, IT.Davgcol, IS.SZs.Vzas, IT.SZs.Vzas);