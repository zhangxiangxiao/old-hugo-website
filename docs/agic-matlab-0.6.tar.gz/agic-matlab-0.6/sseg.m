function Msseg = sseg(Vg, Msmap, Z)
%Spacial Segment Operation
%By Shawn Chang (Zhang Xiang) @ Tianjin University
%Version 0.2, 11/11/2010
%
%Usage: Msseg = sseg(Vg, Msmap, Z)
%       Msseg:  Output segments
%       Vg:     Input iteration vector
%       Z:      Input z-points
%
%Note: This function separates each segment starting from 1

Z=[min(Vg); Z; max(Vg)];
s = 1;
Msseg = zeros(size(Msmap));

for i = 1:numel(Vg)
    if Vg(i) > Z(s+1)
        s = s+1;
    end
    Msseg(Msmap == Vg(i)) = s;
end

Msseg = uint8(Msseg);