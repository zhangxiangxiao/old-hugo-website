function [Mzl, Mtl, Vn] = lumzpoints(Vg, Mslp, n)
%Luminance Z-points Generation
%By Shawn Chang (Zhang Xiang) @ Tianjin University
%Version 0.2, 11/11/2010
%
%Usage: [Mzl, Mtl, Vn] = lumzpoints(Mth, n)
%       Mzl:    Output luminance z-points
%       Mtl:    Output luminance z-points alternation
%       Vn:     Output value indicating number of z-points
%       Vg:     Input scales
%       Mslp:   Input regression slopes, one for at each column
%       n:      Number of spacial segments
%
%Note:  This function uses the function zpoints

%Preparation
Vn = zeros(n,1);
Mzl = [];
Mtl = [];

for i = 1:n
    [Z, T] = zpoints(Vg, Mslp(:,i));
    Vn(i) = numel(Z);
    for j = 1:Vn(i)
        Mzl(j,i) = Z(j);
        Mtl(j,i) = T(j);
    end
end