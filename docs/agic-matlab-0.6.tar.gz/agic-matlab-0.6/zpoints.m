function [Z, T]=zpoints(Vg, slopes)
%0-Points Detection Algorithm
%
%by Shawn Chang @ TJU, Version 0.4, 11/14/2010
%
%Usage: [Z T] = zpoints(Vg, slopes)
%       Vg:     Input vector of scales
%       slopes: Input vector of slopes
%       Z:      Output vector of extrema
%       T:      Output vector of extrema alternation

Z=[];
T=[];
for i = 2:(numel(Vg)-1)
    if slopes(i) <= 0 && slopes(i+1) >= 0
        if abs(slopes(i)) <= abs(slopes(i+1))
            Z = [Z;Vg(i)];
        else
            Z = [Z;Vg(i+1)];
        end
        T = [T;-1];
    elseif slopes(i) >= 0 && slopes(i+1) <= 0
        if abs(slopes(i)) <= abs(slopes(i+1))
            Z = [Z;Vg(i)];
        else
            Z = [Z;Vg(i+1)];
        end
        T = [T;1];
    end
end