%Automatical Image Colorization Automatic Processing
%By Shawn Chang (Zhang Xiang) @ Tianjin University
%Version 0.1, 12/20/2010

Prefix = 'TestPics';

% for i = 0:9
%     FolderPath = [Prefix '/TestPic0' num2str(i)];
%     if exist(FolderPath,'dir')
%         %Source File
%         FileSource = [FolderPath '/' 'Source'];
%         if ~exist(FileSource, 'file')
%             warning([FileSource ' does not exist']);
%             continue;
%         end
%         
%         %Target File
%         FileTarget = [FolderPath '/' 'Target'];
%         if ~exist(FileSource, 'file')
%             warning([FileTarget ' does not exist']);
%             continue;
%         end
%         
%         %Processing
%         movefile(FileSource);
%         movefile(FileTarget);
%         delete([FolderPath '/*']);
%         agic;
%         %close all;
%         movefile('Source', FolderPath);
%         movefile('Source_HL.eps', FolderPath);
%         movefile('Source_Smap', FolderPath);
%         movefile('Source_Sseg', FolderPath);
%         movefile('Target', FolderPath);
%         movefile('Target_G', FolderPath);
%         movefile('Target_HL.eps', FolderPath);
%         movefile('Target_Smap', FolderPath);
%         movefile('Target_Sseg', FolderPath);
%         movefile('Result', FolderPath);
%         movefile('SandT_CC.eps', FolderPath);
%         movefile('SandT_HS.eps', FolderPath);
%         movefile('Report', FolderPath);
%     end
% end

for i = 90:99
    FolderPath = [Prefix '/TestPic' num2str(i)];
    if exist(FolderPath,'dir')
        %Source File
        FileSource = [FolderPath '/' 'Source'];
        if ~exist(FileSource, 'file')
            warning([FileSource ' does not exist']);
            continue;
        end
        
        %Target File
        FileTarget = [FolderPath '/' 'Target'];
        if ~exist(FileSource, 'file')
            warning([FileTarget ' does not exist']);
            continue;
        end
        
        %Processing
        movefile(FileSource);
        movefile(FileTarget);
        delete([FolderPath '/*']);
        agic;
        %close all;
        movefile('Source', FolderPath);
        movefile('Source_HL.eps', FolderPath);
        movefile('Source_Smap', FolderPath);
        movefile('Source_Sseg', FolderPath);
        movefile('Target', FolderPath);
        movefile('Target_G', FolderPath);
        movefile('Target_HL.eps', FolderPath);
        movefile('Target_Smap', FolderPath);
        movefile('Target_Sseg', FolderPath);
        movefile('Result', FolderPath);
        movefile('SandT_CC.eps', FolderPath);
        movefile('SandT_HS.eps', FolderPath);
        movefile('Report', FolderPath);
    end
end