function [Z,T] = zmin(inZ, inT)
%Preserving minimal z-points only
%By Shawn Chang (Zhang Xiang) @ Tianjin University
%Version 0.1, 11/05/2010
%
%Usage: [Z, T] = zmin(inZ, inT)
%       Z, T:       Output Z-points and its alternation
%       inZ, inT:   Input Z-points and its alternation

Z = inZ(inT==-1);
T = inT(inT==-1);