function Y = ycc2rgb(X)
%JFIF YCbCr to RGB Color Space Conversion
%By Shawn Chang (Zhang Xiang) @ Tianjin University
%Version 0.1. 09/23/2010
%
%Usage: Y = ycc2rgb(X)
%       Y:  Output RGB values, uint8
%       X:  Input YCbCr values, uint8

X = double(X);
Y = zeros(size(X));
Y(:,:,1) = X(:,:,1) + 1.402*(X(:,:,3) - 128);
Y(:,:,2) = X(:,:,1) - 0.34414*(X(:,:,2) - 128) - 0.71414*(X(:,:,3) - 128);
Y(:,:,3) = X(:,:,1) + 1.772*(X(:,:,2) - 128);
Y = uint8(Y);