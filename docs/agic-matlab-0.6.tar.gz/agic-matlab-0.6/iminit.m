function I = iminit(Filename)
%Initialize an image structure according to filename
%By Shawn Chang (Zhang Xiang) @ Tianjin Universit
%Version 0.1, 10/31/2010
%
%Usage  I = iminit(Filename)
%       I:          Output image structure
%       Filename:   Input filename
%
%Notes: This function does the following:
%       Read the image
%       Transform the data in the image into YCbCr
%       Downsample the data in YCbCr
%       Establish size information and whole structure of the image

%Constants
w = 512;                %Downsample width

%Define the image structure
I.Drgb = [];            %RGB data for I
I.Dycc = [];            %Ycc data for I
I.Ddycc = [];           %Downsampled Ycc data for I
I.Vsize = [];           %Size of the image, [height, width]
I.Vdsize = [];          %Downsampled size of the image, [height, width]
I.Msmap = [];           %Spacial mapping results
I.Mdsmap = [];          %Downsampled spacial mapping
I.Mths = [];            %Spacial slopes and y-intersects
I.Dthl = [];            %Luminance slopes and y-intersects
I.Vhs = [];             %Spacial histogram
I.Mhl = [];             %Luminance histograms
I.SZs.n = 0;            %Number of adjusted spacial Z-points
I.SZs.Vzs = [];         %Spacial Z-points
I.SZs.Vts = [];         %Spacial Z-points alternation
I.SZs.Vzas = [];        %Adjusted spacial Z-points
I.SZs.Vtas = [];        %Adjusted spacial Z-points alternation
I.SZl.Vn = [];          %Number of adjusted luminance Z-points
I.SZl.Mzl = [];         %Luminance Z-points
I.SZl.Mtl = [];         %Luminance Z-points alternation
I.SZl.Mzal = [];        %Adjusted luminance Z-points
I.SZl.Mtal = [];        %Adjusted luminance Z-points alternation
I.Ssseg.n = 0;          %Number of segments
I.Ssseg.Msseg = [];     %Segments data
I.Davgcol = [];         %Average color data

I.Drgb = imread(Filename);
I.Dycc = rgb2ycc(I.Drgb);
I.Vsize = [size(I.Drgb, 1) size(I.Drgb, 2)];
I.Vdsize = [fix(I.Vsize(1)*w/I.Vsize(2)) w];
I.Ddycc = imresize(I.Dycc, I.Vdsize);
I.Mdsmap = smap(I.Ddycc(:,:,1));
I.Msmap = imresize(I.Mdsmap, I.Vsize);