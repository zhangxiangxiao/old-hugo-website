function [ZS, TS, ZT, TT]=fradjust(inZS, inTS, inZT, inTT)
%Font-Rear 0-Points Adjustment
%
%by Shawn Chang @ TJU, Version 0.1, 02/20/2010
%
%Usage: [ZS, TS, ZT, TT]=fradjust(inZS, inTS, inZT, inTT)
%       inZS, inTS, inZT, inTT: Input parameters
%       ZS, TS, ZT, TT:         Output parameters

deltaS = size(inTS,1);
deltaT = size(inTT,1);
delta = abs(deltaS - deltaT);

ZS=inZS;
TS=inTS;
ZT=inZT;
TT=inTT;
    
if mod(delta, 2) == 1
    if deltaS > deltaT
        if inTS(1) == inTT(1)
            TS=inTS(1:(deltaS-1));
            ZS=inZS(1:(deltaS-1));
        else
            TS=inTS(2:deltaS);
            ZS=inZS(2:deltaS);
        end
    else
        if inTS(1) == inTT(1)
            TT=inTT(1:(deltaT-1));
            ZT=inZT(1:(deltaT-1));
        else
            TT=inTT(2:deltaT);
            ZT=inZT(2:deltaT);
        end
    end
end