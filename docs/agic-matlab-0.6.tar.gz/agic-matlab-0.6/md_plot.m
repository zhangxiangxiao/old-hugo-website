%Plotting for AGIC
%By Shawn Chang (Zhang Xiang) @ TJU
%Version 0.2, 11/11/2010
%
%IR must have been initialized
%Spacial Segments must have been generated
%Luminance Z-points must have been computed
%Luminance-Color Correspondence must have been computed.
%Colorization must have been done

%Constants
col = 'mbgyc';          %Plotting colors. 

%Preparing Plotting data
Data.Seg.S = [];        %For plotting: spacial segments for source
Data.Seg.T = [];        %For plotting: spacial segments for source
Data.P.Phs = [];        %For plotting: spacial histogram plots
Data.P.Phl.S = [];      %Source luminance plotting
Data.P.Phl.T = [];      %Target luminance plotting

%Prepare used graphs
if ~exist('FI', 'var')
    FI = figure;        %Image, spacial mapping and spacial segments values
    title('This figure will be used to draw image, spacial mapping and special segments');
end
if ~exist('Fhs', 'var')
    Fhs = figure;       %Spacial mapping histogram
    title('This figure will be used to draw spacial mapping histogram and z-points');
end
if ~exist('FhlS', 'var')
    FhlS = figure;      %Luminance histograms
    title('This figure will be used to draw source luminance histograms and z-points');
end
if ~exist('FhlT', 'var')
    FhlT = figure;      %Luminance histograms
    title('This figure will be used to draw source luminance histograms and z-points');
end
if ~exist('FC','var')
    FC = figure;       %Color Correspondence Map
    title('This figure will be used to draw the color correspondence map');
end
if ~exist('FR', 'var')
    FR = figure;        %Final result
    title('This figure will be used to draw the final result');
end
figure(FI);
clf(FI);
figure(Fhs);
clf(Fhs);
figure(FhlS);
clf(FhlS);
figure(FhlT);
clf(FhlT);
figure(FC);
clf(FC);
figure(FR);
clf(FR);

%Calculating Segments
Data.Seg.S = uint8(double(IS.Ssseg.Msseg)/(IS.Ssseg.n)*256);
Data.Seg.T = uint8(double(IT.Ssseg.Msseg)/(IT.Ssseg.n)*256);

%Plotting images, spacial mapping and spacial segments
figure(FI);
subplot(321);
image(IS.Drgb);
title('Source Image');
axis equal; axis tight;
subplot(322);
image(repmat(IT.Dycc(:,:,1),[1 1 3]));
title('Target Image');
axis equal; axis tight;
subplot(323);
image(repmat(IS.Msmap,[1 1 3]));
title('Source Spacial Map');
axis equal; axis tight;
subplot(324);
image(repmat(IT.Msmap,[1 1 3]));
title('Target Spacial Map');
axis equal; axis tight;
subplot(325);
image(repmat(Data.Seg.S, [1 1 3]));
title('Source Spacial Segments');
axis equal; axis tight;
subplot(326);
image(repmat(Data.Seg.T, [1 1 3]));
title('Target Spacial Segments');
axis equal; axis tight;

%Plotting spacial histograms
figure(Fhs);
hold on;
Data.P.Phs(1) = plot(Vg, IS.Vhs, 'g');
Data.P.Phs(2) = plot(Vg, IT.Vhs, 'b');
for i = 1:IS.SZs.n
    plot(IS.SZs.Vzas(i), IS.Vhs(IS.SZs.Vzas(i) + 1), 'or', 'linewidth',5);
    plot(IT.SZs.Vzas(i), IT.Vhs(IT.SZs.Vzas(i) + 1), 'or', 'linewidth',5);
end
legend(Data.P.Phs,'Source', 'Target');
xlabel('Spacial map value');
ylabel('Histogram proportion');
title('Spacial mapping histograms and z-points');
axis tight;
hold off;

%Plotting luminance histograms
figure(FhlS);
hold on;
for i=1:IS.Ssseg.n
    Data.P.Phl.S(i) = plot(Vg, IS.Mhl(:,i), col(mod(i,numel(col))+1));
    for j = 1:IS.SZl.Vn(i)
        plot(IS.SZl.Mzal(j, i), IS.Mhl(IS.SZl.Mzal(j,i) + 1, i), 'or','linewidth',5);
    end
end
legend(Data.P.Phl.S, 'Segment #1', 'Segment #2', 'Segment #3', 'Segment #4', ...
        'Segment #5', 'Segment #6', 'Segment #7', 'Segment #8', 'Segment #9');
xlabel('Luminance');
ylabel('Histogram proportion');
title('Source luminance histograms and z-points');
axis tight;
hold off;

figure(FhlT);
hold on;
for i=1:IT.Ssseg.n
    Data.P.Phl.T(i) = plot(Vg, IT.Mhl(:,i), col(mod(i,numel(col))+1));
    for j = 1:IT.SZl.Vn(i)
        plot(IT.SZl.Mzal(j, i), IT.Mhl(IT.SZl.Mzal(j,i) + 1, i), 'or','linewidth',5);
    end
end
legend(Data.P.Phl.T, 'Segment #1', 'Segment #2', 'Segment #3', 'Segment #4', ...
        'Segment #5', 'Segment #6', 'Segment #7', 'Segment #8', 'Segment #9');
xlabel('Luminance');
ylabel('Histogram proportion');
title('Target luminance histograms and z-points');
axis tight;
hold off;

%Plot the color correspondence
figure(FC);
image(ycc2rgb(IR.Davgcol));
axis equal;axis tight;
xlabel('Spacial map value');
ylabel('Luminance');
title('The global color correspondence');

%Plot the final result
figure(FR)
image(IR.Drgb);
axis equal; axis tight;