function [MzalS, MtalS, MzalT, MtalT, Vna] = ...
    lumzadjust(MzlS, MtlS, MzlT, MtlT, n, VnS, VnT, MhlS, MhlT)
%Luminance z-points adjustment
%By Shawn Chang (Zhang Xiang) @ Tianjin University
%Version 0.1, 11/06/2010
%
%Usage: [MzalS, MtalS, MzalT, MtalT, VnaS, VnaT] = 
%                 lumzadjut(MzlS, MtlS, MzlT, MtlT, VnS, VnT, MhlS, MhlT)
%       MzalS, MtalS:   Output Z-points and its alternation for Source
%       MzalT, MtalT:   Output Z-points and its alternation for Target
%       Vna:            Output Number of adjusted z-points
%       MzlS, MtlS:     Input Z-points and its alternation for Source
%       MzlT, MtlT:     Input Z-points and its alternation for Target
%       n:              Input number of spacial segments
%       VnS, VnT:       Input number of Z-points
%       MhlS, MhlT:     Input luminance histograms for Source and Target
%
%Note:  This function uses the function zadjust

%Preparation
Vna = zeros(n,1);

%Calculation
for i = 1:n
    ZS = MzlS(1:VnS(i), i);
    ZT = MzlT(1:VnT(i), i);
    TS = MtlS(1:VnS(i), i);
    TT = MtlT(1:VnT(i), i);
    VhS = MhlS(:,i);
    VhT = MhlT(:,i);
    
    [ZaS, TaS, ZaT, TaT] = zadjust(ZS,TS,ZT,TT,VhS,VhT);
    Vna(i) = numel(ZaS);
    for j = 1:Vna(i)
        MzalS(j,i) = ZaS(j);
        MzalT(j,i) = ZaT(j);
        MtalS(j,i) = TaS(j);
        MtalT(j,i) = TaT(j);
    end
    
end
