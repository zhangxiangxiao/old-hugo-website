function Y = texcontr(X)
%Scaled RMS Contrast Computation
%By Shawn Chang (Zhang Xiang) @ Tianjin University
%Version 0.2, 09/20/2010
%
%Usage: Y = texcontr(X)
%       Y: Output value of contrast values, between [0,1]
%       X: Input value of stacked data

mX = mean(X,2);
stdX = std(X,0,2);
Y = stdX./(mX+1);
Y = Y/max(Y);
Y(Y>1) = 1;
Y(Y<0) = 0;