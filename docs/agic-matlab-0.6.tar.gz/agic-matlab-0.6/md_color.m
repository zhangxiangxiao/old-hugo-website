%Colorization Model for AGIC
%By Shawn Chang (Zhang Xiang) @ TJU
%Version 0.1, 11/07/2010
%
%IR must have been initialized
%Spacial Segments must have been generated
%Luminance Z-points must have been computed
%Luminance-Color Correspondence must have been computed.

IR.Dycc = colorize(Vg, IT.Dycc(:,:,1), IT.Msmap, IR.Davgcol, flagLP, colorscale);
IR.Drgb = ycc2rgb(IR.Dycc);