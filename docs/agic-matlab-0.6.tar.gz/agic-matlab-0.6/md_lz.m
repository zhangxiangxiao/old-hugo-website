%Luminance Z-points Model for AGIC
%By Shawn Chang (Zhang Xiang) @ TJU
%Version 0.1, 11/07/2010
%
%IT and IS must have been initialized
%Spacial Segments be have been generated

%Histogram Generation
IS.Mhl = lumhist(Vg, IS.Ddycc(:,:,1), IS.Ssseg.Msseg, IS.Ssseg.n);
IT.Mhl = lumhist(Vg, IT.Ddycc(:,:,1), IT.Ssseg.Msseg, IT.Ssseg.n);

%Histogram Regression
IS.Dthl = lumlwr(Vg, IS.Mhl, IS.Ssseg.n, tau);
IT.Dthl = lumlwr(Vg, IT.Mhl, IT.Ssseg.n, tau);

%Luminance z-points generation
[IS.SZl.Mzl, IS.SZl.Mtl, IS.SZl.Vn] = lumzpoints(Vg, squeeze(IS.Dthl(:,2,:)),IS.Ssseg.n);
[IT.SZl.Mzl, IT.SZl.Mtl, IT.SZl.Vn] = lumzpoints(Vg, squeeze(IT.Dthl(:,2,:)),IT.Ssseg.n);

%Detect non-zpoints
for i = 1:IS.Ssseg.n
    if IS.SZl.Vn(i) == 0 || IT.SZl.Vn(i) == 0
        IS.SZl.Vn(i) = 1;
        IT.SZl.Vn(i) = 1;
        IS.SZl.Mzl(1,i) = Vg(2);
        IT.SZl.Mzl(1,i) = Vg(2);
        IS.SZl.Mtl(1,i) = 1;
        IT.SZl.Mtl(1,i) = 1;
    end
end

%Luminance z-points adjustment
[IS.SZl.Mzal, IS.SZl.Mtal, IT.SZl.Mzal, IT.SZl.Mtal, IS.SZl.Vn] = ...
    lumzadjust(IS.SZl.Mzl, IS.SZl.Mtl, IT.SZl.Mzl, IT.SZl.Mtl, IS.Ssseg.n, IS.SZl.Vn, IT.SZl.Vn, IS.Mhl, IT.Mhl);
IT.SZl.Vn = IS.SZl.Vn;