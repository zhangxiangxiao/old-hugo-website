function [Mc, gamma] = wsagc(Mg, Sm)
%Statistical Adaptive Gamma Correction for a With Adaptive Step
%By Zhang Xiang (Shawn Chang) @ Tianjin University
%Version 0.1, 01/23/2010
%
%Usage: [Mc, gamma] = wsagc(Mg, Sm)
%       Mc:     Output corrected matrix
%       gamma:  Output gamma value
%       Mg:     Input grayscale matrix, in [0,1]
%       Sm:     Target statistical mean. 0.5 if not provided. (Optional)
%
%Note:  This function compute the gamma value using Newton's Method

if ~exist('Sm','var')
    Sm = 0.5;
end

if (Sm >= 1 || Sm <= 0)
    error('Input statistical mean must between 0 and 1.');
end

%Constants
STEP_MULTIPLYER = 16;

%For zero-values, must be scaled to the minimum value
Mc = Mg;
Mc(Mc == 0) = 1/10^308;
mu = mean(Mc(:));

%Iterations
gamma = mu/Sm;
gamma1 = gamma - ((mean(Mc(:).^gamma) - Sm))/(mean((Mc(:).^gamma).*log(Mc(:))) - Sm);

%Iteration
h = 1;
while abs(gamma - gamma1)/gamma > 0.001
    gamma = gamma1;
    gamma1 = gamma - h*((mean(Mc(:).^gamma) - Sm))/(mean((Mc(:).^gamma).*log(Mc(:))) - Sm);
    
    if (mean(Mc(:).^gamma1) - Sm)*(mu - Sm) > 0
        h = h*STEP_MULTIPLYER;
    else
        while h > 1 && (mean(Mc(:).^gamma1) - Sm)*(mu - Sm) < 0
            h = h/STEP_MULTIPLYER;
            gamma1 = gamma - h*((mean(Mc(:).^gamma) - Sm))/(mean((Mc(:).^gamma).*log(Mc(:))) - Sm);
        end
    end
end

Mc = Mg.^gamma;