%Spacial Segments Model for AGIC
%By Shawn Chang (Zhang Xiang) @ TJU
%Version 0.3, 11/11/2010
%
%IT and IS must have been initialized

%Computing histograms
IS.Vhs = histgen(Vg, IS.Mdsmap, ones(IS.Vdsize));
IT.Vhs = histgen(Vg, IT.Mdsmap, ones(IT.Vdsize));

%If edge values will be deleted
if hist_elim == true
    IS.Vhs(1) = IS.Vhs(2);
    IT.Vhs(1) = IT.Vhs(2);
    IS.Vhs(numel(Vg)) = IS.Vhs(numel(Vg)-1);
    IT.Vhs(numel(Vg)) = IT.Vhs(numel(Vg)-1);
end

%Performing Locally Weighted Linear Regression
IS.Mths = lwrlin(Vg, IS.Vhs, tau);
IT.Mths = lwrlin(Vg, IT.Vhs, tau);

%Z-points Generation and Adjustment
[IS.SZs.Vzs, IS.SZs.Vts] = zpoints(Vg, IS.Mths(:,2));
[IT.SZs.Vzs, IT.SZs.Vts] = zpoints(Vg, IT.Mths(:,2));
IS.SZs.n = numel(IS.SZs.Vzs);
IT.SZs.n = numel(IT.SZs.Vzs);
if IS.SZs.n ~= 0 && IT.SZs.n ~=0
    [IS.SZs.Vzas, IS.SZs.Vtas, IT.SZs.Vzas, IT.SZs.Vtas] = zadjust(IS.SZs.Vzs, IS.SZs.Vts, IT.SZs.Vzs, IT.SZs.Vts, IS.Vhs, IT.Vhs);
    [IS.SZs.Vzas, IS.SZs.Vtas] = zmin(IS.SZs.Vzas, IS.SZs.Vtas);
    [IT.SZs.Vzas, IT.SZs.Vtas] = zmin(IT.SZs.Vzas, IT.SZs.Vtas);
    IS.SZs.n = numel(IS.SZs.Vzas);
    IT.SZs.n = numel(IT.SZs.Vzas);
end
if IS.SZs.n == 0 || IT.SZs.n == 0
    IS.SZs.n = 0;
    IT.SZs.n = 0;
    IS.SZs.Vzas = [];
    IT.SZs.Vzas = [];
    IS.SZs.Vtas = [];
    IT.SZs.Vtas = [];
end

%Generating Spacial Segments
IS.Ssseg.Msseg = sseg(Vg, IS.Mdsmap, IS.SZs.Vzas);
IT.Ssseg.Msseg = sseg(Vg, IT.Mdsmap, IT.SZs.Vzas);
IS.Ssseg.n = numel(IS.SZs.Vzas) + 1;
IT.Ssseg.n = numel(IT.SZs.Vzas) + 1;
